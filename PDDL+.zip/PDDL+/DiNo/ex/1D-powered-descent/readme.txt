suggested execution:

../../bin/dino descent.pddl prob_earth01.pddl --custom 1 5 5 --force
./descent_planner -th50
