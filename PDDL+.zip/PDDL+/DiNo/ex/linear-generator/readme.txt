suggested execution:

../../bin/dino generator.pddl prob01.pddl --custom 1 5 5 --force
./generator_planner -th1000
