suggested execution:

../../bin/dino solarrover.pddl prob01.pddl --custom 1 5 5 --force
./solarrover_planner -th100
