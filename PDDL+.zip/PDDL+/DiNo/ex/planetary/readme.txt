suggested execution:

../../bin/dino planetary_lander.pddl planetary_lander_problem.pddl
./planetary_lander_planner -th50

