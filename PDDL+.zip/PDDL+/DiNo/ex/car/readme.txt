suggested execution:

../../bin/dino car.pddl prob01.pddl --custom 1 5 5 --force
./car_planner -th12
