Instances for linear generator domain

Instances generated on the basis of the benchmark presented in Cashmore's ICAPS 2016 work
