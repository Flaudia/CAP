Instances for non_linear version of the generator domain

These instances have been generated in a way to be equivalent to Daniel Bryce's  instances (AAAI 2015 work)
